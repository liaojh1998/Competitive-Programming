#include <vector>
#include <iostream>
#include <set>
#include <algorithm>
#include <random>
#include <queue>

using namespace std;

struct Square
{
    int i,j;
    int cost;

    bool operator<(const Square &other) const
    {
        return cost > other.cost;
    }
};

bool isOK(int i, int j, int N)
{
    if(i < 0 || j < 0 || i >= N || j >= N)
        return false;
    return true;
}

void doCase()
{
    int n;
    int carx,cary;
    cin >> n >> carx >> cary;
    carx = (n-1)/2+carx;
    cary = (n-1)/2-cary;
    char *board = new char[n*n];
    bool *visited = new bool[n*n];
    for(int i=0; i<n*n; i++)
    {
        char c;
        cin >> c;
        board[i] = c;
        visited[i] = false;
    }

    priority_queue<Square> q;
    Square start;
    start.i = (n-1)/2;
    start.j = (n-1)/2;
    start.cost = 0;
    q.push(start);
    int dx[] = {-1, 0, 1, 0, -1, -1, 1, 1};
    int dy[] = {0, -1, 0, 1, -1, 1, -1, 1};
    int costs[] = {2, 1, 0, 1, 2, 2, 0, 0};
    while(!q.empty())
    {
        Square s = q.top();
        q.pop();
        if(visited[n*s.j+s.i])
            continue;
        if(s.i == carx && s.j == cary)
        {
            if(s.cost >= (n-1)/2)
                cout << "TERMINATED" << endl;
            else
                cout << "ESCAPED" << endl;
            return;
        }
        visited[n*s.j+s.i] = true;
        for(int i=0; i<8; i++)
        {
            int x = s.i + dx[i];
            int y = s.j + dy[i];
            if(!isOK(x,y,n))
                continue;
            if(board[n*y+x] != '.')
                continue;
            if(visited[n*y+x])
                continue;
            Square news;
            news.i = x;
            news.j = y;
            news.cost = s.cost + costs[i];
            q.push(news);
        }
    }
    cout << "TERMINATED" << endl;
}

int main()
{
    int t;
    cin >> t;
    for(int i=0; i<t; i++)
        doCase();
}
