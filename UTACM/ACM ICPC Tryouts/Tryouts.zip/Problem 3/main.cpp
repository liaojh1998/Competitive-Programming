#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

void doCase()
{
    string s;
    getline(cin, s);
    bool oneword = true;
    for(int i=0; i<s.length(); i++)
        if(s[i] == ' ')
            oneword = false;
    if(oneword)
        cout << s << " Returns" << endl;
    else
        cout << s << ": Age of Darkness" << endl;
}

int main()
{
    int t;
    cin >> t;
    cin.ignore();
    for(int i=0; i<t; i++)
        doCase();
}
