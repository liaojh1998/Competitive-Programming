#include <iostream>
#include <vector>
#include <string>

using namespace std;

void MX(int *M, int *X, int A)
{
    int *result = new int[A*A];
    for(int i=0; i<A; i++)
        for(int j=0; j<A; j++)
        {
            int sum=0;
            for(int k=0; k<A; k++)
                sum += M[A*i+k]*X[A*k+j];
            result[A*i+j] = (sum == 0 ? 0 : 1);
        }
    for(int i=0; i<A*A; i++)
        X[i] = result[i];
    delete[] result;
}

void XMT(int *M, int *X, int A)
{
    int *result = new int[A*A];
    for(int i=0; i<A; i++)
        for(int j=0; j<A; j++)
        {
            int sum=0;
            for(int k=0; k<A; k++)
                sum += X[A*i+k]*M[A*j+k];
            result[A*i+j] = (sum == 0 ? 0 : 1);
        }
    for(int i=0; i<A*A; i++)
        X[i] = result[i];
    delete[] result;
}

void doCase()
{
    int A;
    cin >> A;
    int F;
    cin >> F;
    int *M = new int[A*A];
    int *X = new int[A*A];
    for(int i=0; i<A; i++)
        for(int j=0; j<A; j++)
        {
            M[A*i+j] = (i == j) ? 1 : 0;
            X[A*i+j] = (i == j) ? 1 : 0;
        }
    for(int i=0; i<F; i++)
    {
        int c1, c2;
        cin >> c1 >> c2;
        M[A*c1+c2] = 1;
    }

    int N=0;
    while(true)
    {
        bool zero=false;
        for(int i=0; i<A*A; i++)
            if(X[i] == 0)
                zero = true;
        if(!zero)
        {
            cout << N << endl;
            return;
        }
        else if(N > A)
        {
            cout << "IMPOSSIBLE" << endl;
            return;
        }
        N++;
        MX(M, X, A);
        XMT(M, X, A);
    }
}

int main()
{
    int cases;
    cin >> cases;
    for(int i=0; i<cases; i++)
    {        
        doCase();
    }
    return 0;
}
