#include <vector>
#include <iostream>
#include <set>
#include <algorithm>

using namespace std;

vector<int> shuffle(const vector<int> &P)
{
    vector<int> cur = P;
    int N = P.size();
    bool changed = true;
    while(changed)
    {
        changed = false;
        vector<int> desired;
        for(int i=0; i<N; i++)
        {
            if( (i != 0) && (cur[i-1] + 1 == cur[i])
                    && (i == N-1 || cur[i] < cur[i+1]-1)
                    )
                desired.push_back(cur[i]+1);
            else if( (i != N-1) && (cur[i] + 1 == cur[i+1])
                    && (i == 0 || cur[i-1] < cur[i]-1)
                    )
                desired.push_back(cur[i]-1);
            else
                desired.push_back(cur[i]);
        }
        for(int i=0; i<N-1; i++)
        {
            if(desired[i] == desired[i+1])
            {
                desired[i] = cur[i];
                desired[i+1] = cur[i+1];
            }
        }
        for(int i=0; i<N; i++)
        {
            if(desired[i] != cur[i])
            {
                changed = true;
                cur[i] = desired[i];
            }
        }
    }
    return cur;
}

void doCase()
{
    int N;
    cin >> N;
    vector<int> P;
    for(int i=0; i<N; i++)
    {
        int p;
        cin >> p;
        P.push_back(p);
    }
    sort(P.begin(), P.end());
    vector<int> final = shuffle(P);
    int maxmoved = 0;
    for(int i=0; i<N; i++)
        maxmoved = max(maxmoved, abs(P[i]-final[i]));
    cout << maxmoved << endl;
}

int main()
{
	int T;
	cin >> T;
	for(int i=0; i<T; i++)
	{
                doCase();
	}
}
