#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

void doCase()
{
    int f, xp, yp;
    cin >> f >> xp >> yp;

    vector<int> xs, ys;
    xs.push_back(xp);
    ys.push_back(yp);
    for(int i=0; i<f; i++)
    {
        int x, y;
        cin >> x >> y;
        xs.push_back(x);
        ys.push_back(y);
    }
    sort(xs.begin(), xs.end());
    sort(ys.begin(), ys.end());
    if(f % 2 ==0)
    {
        cout << xs[f/2] << " " << ys[f/2] << endl;
    }
    else
    {
        cout << (xs[f/2] + xs[1+f/2])/2 << " " << (ys[f/2]+ys[1+f/2])/2 << endl;
    }
}

int main()
{
    int T;
    cin >> T;
    for(int i=0; i<T; i++)
        doCase();
}
