#include <vector>
#include <iostream>
#include <set>

using namespace std;

void doCase()
{
	int N, B, M;
	cin >> N >> B >> M;
	vector<int> wings;
	for(int i=0; i<M; i++)
	{
		int H;
		cin >> H;
		wings.push_back(H);
	}
	set<int> vals;
	set<int> old;
	vals.insert(0);
	int eaten=0;
	while(true)
	{
		old.insert(vals.begin(), vals.end());
		set<int> newvals;
		eaten++;
		for(set<int>::iterator it=vals.begin(); it != vals.end(); ++it)
		{
			for(int j=0; j<M; j++)
			{
				int newval = *it + wings[j];
				if(B == 0 && newval == N)
				{
					cout << eaten << endl;
					return;
				}
				if(B > 0 && newval >= N && (newval-N)%B == 0)
				{
					cout << eaten << endl;
					return;
				}
				if(old.count(newval) == 0)
					newvals.insert(newval);
			}
		}
		vals = newvals;
	}
}

int main()
{
	int T;
	cin >> T;
	for(int i=0; i<T; i++)
	{
                doCase();
	}
}
